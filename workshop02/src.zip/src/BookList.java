/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import entity.Book;
import util.MyList;

/**
 *
 * @author TrongDuyDao
 */
public class BookList {

    //a list of book
    private MyList books;

    public MyList getBooks() {
        return books;
    }

    
    
    public BookList() {
        books = new MyList();
    }

    //1.0 accept information of a Book
    private Book getBook() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    
    //1.1 accept and add a new Book to the end of book list
    public void addLast() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    //1.2 output information of book list
    public void list() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    //1.3 search book by book code
    public void search() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    //1.4 accept and add a new Book to the begining of book list
    public void addFirst() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    //1.5 Add a new Book after a position k
    public void addAfter() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    //1.6 Delete a Book at position k
    public void deleteAt() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
}
